# LinkCharts — Android / private web deployment

This package prepares the upstream LinkCharts 1.3.0 source to run as a private HTTPS website.

## What was changed
- The server can bind to the hosting platform's network interface and port.
- Public mode is protected by HTTP Basic Authentication. The service refuses to start in public mode if the password is shorter than 16 characters.
- Persistent user configuration and saved data are directed to `/var/data`.
- `Dockerfile` and `render.yaml` are included for Render deployment.

## Deploy from Android (Render)
1. Extract this ZIP on your Android phone.
2. Create a new **private or public GitHub repository** (for example `my-linkcharts`) and upload the *contents* of the extracted folder to its root. Do not upload the ZIP as a single file.
3. Open https://dashboard.render.com/ and sign in.
4. Choose **New → Blueprint**, connect GitHub, and select your `my-linkcharts` repository. Render reads `render.yaml`.
5. When asked for `LINKCHARTS_PASSWORD`, enter a unique password with at least 16 characters. Do not reuse your email or banking password. Keep it private.
6. Create the service. Wait for the deploy to finish. Render will show an HTTPS URL such as `https://linkcharts-private.onrender.com`.
7. Open that URL in Chrome on Android. The browser will ask for the username and password. Username is `linkcharts`; use the password you set.
8. In Chrome, use **⋮ → Add to Home screen** if you want an app-like shortcut.

## Important notes
- The included Render configuration uses a paid Starter web service and a 1 GB persistent disk so saved watchlists, drawings, paper trades, settings, and provider keys can survive restarts. Check Render's current pricing before creating it.
- Do not remove authentication or expose the service without HTTPS and a strong password: the app can store provider API keys and personal trading data.
- The original project is designed around local use. Broker OAuth callbacks that are hard-coded to `127.0.0.1` may not work unchanged on a hosted domain; this package does not claim broker login compatibility.
- Market data depends on upstream providers and their rate limits. A live chart is not guaranteed for every instrument.
- This is the upstream LinkCharts project with deployment support; it has not been rewritten into a native Android app.
