// LinkCharts server: static files + market-data API with pluggable providers.
// Defaults to loopback. Public hosting requires LINKCHARTS_PUBLIC=1 and a strong password.
// Usage: node server.mjs [port] [--open]   (--open launches the browser once it's running)
import http from "node:http";
import crypto from "node:crypto";
import { exec } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { PROVIDERS, MARKETS, INTERVALS, marketOf, yahoo, ProviderError } from "./providers.mjs";
import { runScreen, performance, SCREENER_MARKETS, SECTORS } from "./screener.mjs";

const root = path.dirname(fileURLToPath(import.meta.url));
const port = Number(process.env.PORT || process.env.LINKCHARTS_PORT || process.argv.slice(2).find((a) => /^\d+$/.test(a)) || 5174);
const host = process.env.LINKCHARTS_HOST || "127.0.0.1";
// Public hosting must be password-protected. Set LINKCHARTS_PASSWORD in the host's secret settings.
const accessUser = process.env.LINKCHARTS_USER || "linkcharts";
const accessPassword = process.env.LINKCHARTS_PASSWORD || "";
if (process.env.LINKCHARTS_PUBLIC === "1" && accessPassword.length < 16) {
  throw new Error("For public hosting, set LINKCHARTS_PASSWORD to at least 16 characters.");
}
function authorized(req) {
  if (process.env.LINKCHARTS_PUBLIC !== "1") return true;
  const header = req.headers.authorization || "";
  if (!header.startsWith("Basic ")) return false;
  let supplied;
  try { supplied = Buffer.from(header.slice(6), "base64").toString("utf8"); } catch { return false; }
  const split = supplied.indexOf(":");
  if (split < 0) return false;
  const user = Buffer.from(supplied.slice(0, split));
  const pass = Buffer.from(supplied.slice(split + 1));
  const expectedUser = Buffer.from(accessUser);
  const expectedPass = Buffer.from(accessPassword);
  return user.length === expectedUser.length && pass.length === expectedPass.length &&
    crypto.timingSafeEqual(user, expectedUser) && crypto.timingSafeEqual(pass, expectedPass);
}
// The installed app keeps its data in the user's app-data folder (the install folder is replaced on updates).
const dataDir = process.env.LINKCHARTS_DATA || path.join(root, "data");
const openBrowser = process.argv.includes("--open");
function launchBrowser(url) {
  const cmd = process.platform === "win32" ? `start "" "${url}"` : process.platform === "darwin" ? `open "${url}"` : `xdg-open "${url}"`;
  exec(cmd, () => { /* no browser to launch; the URL is printed above */ });
}
const configPath = path.join(dataDir, "config.json");
// Everything the app remembers (watchlists, alerts, drawings, paper trades, layouts, theme…)
// is mirrored here so it survives cleared browser data or a different browser.
const userDataPath = path.join(dataDir, "userdata.json");
function readUserData() {
  try { return JSON.parse(fs.readFileSync(userDataPath, "utf8")); } catch { return { savedAt: 0, items: {} }; }
}
function writeUserData(data) {
  fs.mkdirSync(path.dirname(userDataPath), { recursive: true });
  const tmp = userDataPath + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(data));
  fs.renameSync(tmp, userDataPath); // atomic: a crash mid-write never leaves a half-written file
}
const types = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".svg": "image/svg+xml" };
const SYMBOL_RE = /^[\^A-Z0-9&.\-=]{1,30}$/i;

// ---------------- config (API keys + routing) ----------------

function loadConfig() {
  try { return JSON.parse(fs.readFileSync(configPath, "utf8")); } catch { return { providers: {}, routing: {} }; }
}
function saveConfig(cfg) {
  fs.mkdirSync(path.dirname(configPath), { recursive: true });
  fs.writeFileSync(configPath, JSON.stringify(cfg, null, 2));
}
let config = loadConfig();
config.providers ??= {};
config.routing ??= {};

const isConfigured = (id) => {
  const p = PROVIDERS[id];
  if (p.builtIn) return true;
  const c = config.providers[id];
  return p.fields.every((f) => f.optional || c?.[f.key]) && (!p.ready || p.ready(c));
};
const mask = (v) => (v ? `••••${String(v).slice(-4)}` : "");

/** Default source order per market when routing is "auto". */
// Free sources other than Yahoo/Binance (Upstox, Coinbase, Kraken, CoinGecko) are opt-in via
// the per-market table, so the automatic order only reaches for them as a fallback.
const AUTO_ORDER = {
  india: ["kite", "fyers", "eodhd", "twelvedata", "yahoo", "upstox"],
  us: ["alpaca", "polygon", "tiingo", "twelvedata", "fmp", "eodhd", "tradier", "marketstack", "alphavantage", "yahoo"],
  global: ["eodhd", "twelvedata", "fmp", "marketstack", "alphavantage", "yahoo"],
  crypto: ["binance", "coinbase", "alpaca", "tiingo", "twelvedata", "polygon", "kraken", "yahoo", "coingecko"],
  forex: ["twelvedata", "polygon", "tiingo", "fmp", "eodhd", "alphavantage", "yahoo"],
  futures: ["yahoo"],
};
// A key-less provider (like CoinGecko without its optional key) only joins "auto" when the user saved settings for it.
const keyOptional = (id) => PROVIDERS[id].fields?.length && PROVIDERS[id].fields.every((f) => f.optional);

function candidateSources(symbol, interval) {
  const market = marketOf(symbol);
  const chosen = config.routing[market];
  const explicit = chosen && chosen !== "auto";
  const order = explicit ? [chosen, "yahoo"] : AUTO_ORDER[market];
  return [...new Set(order)].filter((id) => {
    const p = PROVIDERS[id];
    if (!p || !isConfigured(id) || !p.markets.includes(market) || (p.supports && !p.supports(symbol, interval))) return false;
    return explicit || !keyOptional(id) || !!config.providers[id];
  });
}

// ---------------- caching ----------------

const cache = new Map();
async function cached(key, ttlMs, fn) {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < ttlMs) return hit.value;
  const value = await fn();
  cache.set(key, { at: Date.now(), value });
  if (cache.size > 800) cache.delete(cache.keys().next().value);
  return value;
}

// Yahoo's chartPreviousClose is the close before the *requested range*; derive the real previous session close.
const dayKey = (unix, off) => new Date((unix + off) * 1000).toISOString().slice(0, 10);
async function snapshot(symbol) {
  return cached(`snap:${symbol}`, 15_000, async () => {
    const daily = await yahoo.raw(symbol, "1d", "5d");
    const c = daily.candles, m = daily.meta;
    const lastIsToday = c.length && m.marketTime && dayKey(c[c.length - 1].time, m.gmtoffset) === dayKey(m.marketTime, m.gmtoffset);
    m.prevClose = (lastIsToday ? c[c.length - 2] : c[c.length - 1])?.close ?? m.prevClose;
    m.market = marketOf(symbol);
    const now = Date.now() / 1000;
    m.marketOpen = m.market === "crypto" ? true : !!(m.session && now >= m.session.start && now < m.session.end);
    m.spark = c.slice(-5).map((x) => x.close);
    return m;
  });
}

// ---------------- API ----------------

async function chart(symbol, interval) {
  const sources = candidateSources(symbol, interval);
  const errors = [];
  let candles = null, used = null;
  for (const id of sources) {
    try {
      const ttl = interval.endsWith("m") ? 8_000 : 60_000;
      candles = await cached(`c:${id}:${symbol}:${interval}`, ttl, () => PROVIDERS[id].candles(symbol, interval, config.providers[id] || {}));
      if (!candles.length) throw new ProviderError("returned no candles", 404);
      used = PROVIDERS[id];
      break;
    } catch (err) {
      errors.push(`${PROVIDERS[id].name}: ${err.message}`);
    }
  }
  if (!used) throw new ProviderError(errors.join(" · ") || "No data source supports this symbol", 404);
  let meta;
  try { meta = await snapshot(symbol); } catch {
    const last = candles[candles.length - 1];
    meta = { symbol, name: symbol, exchange: "", currency: "", gmtoffset: 0, price: last.close, prevClose: candles[candles.length - 2]?.close, market: marketOf(symbol), marketOpen: false };
  }
  return {
    meta, candles,
    source: { id: used.id, name: used.name, live: !!used.live, stream: used.stream?.(symbol, interval) || null },
    fallback: errors.length ? errors : null,
  };
}

function providersView() {
  return {
    markets: MARKETS,
    routing: Object.fromEntries(Object.keys(MARKETS).map((m) => [m, config.routing[m] || "auto"])),
    providers: Object.values(PROVIDERS).map((p) => ({
      id: p.id, name: p.name, builtIn: !!p.builtIn, markets: p.markets, note: p.note, live: !!p.live,
      configured: isConfigured(p.id),
      // Brokers you log in to (Zerodha): keys saved but today's login still needed.
      ...(p.login ? {
        login: {
          label: p.login.label, needed: !isConfigured(p.id), user: config.providers[p.id]?.user || "",
          keysSaved: p.fields.every((f) => f.optional || config.providers[p.id]?.[f.key]),
          redirect: `http://127.0.0.1:${port}/api/${p.id}/callback`,
        },
      } : {}),
      fields: (p.fields || []).map((f) => ({ ...f, value: f.secret ? mask(config.providers[p.id]?.[f.key]) : config.providers[p.id]?.[f.key] || "" })),
    })),
  };
}

async function readBody(req, maxChars = 20_000) {
  let s = "";
  for await (const chunk of req) { s += chunk; if (s.length > maxChars) throw new ProviderError("Body too large", 413); }
  return s ? JSON.parse(s) : {};
}

async function handleApi(req, url) {
  const p = url.pathname;
  if (p === "/api/chart") {
    const symbol = url.searchParams.get("symbol") || "";
    const interval = url.searchParams.get("interval") || "1d";
    if (!SYMBOL_RE.test(symbol) || !INTERVALS.includes(interval)) throw new ProviderError("Bad symbol or interval", 400);
    return chart(symbol, interval);
  }
  if (p === "/api/quotes") {
    const symbols = (url.searchParams.get("symbols") || "").split(",").filter((s) => SYMBOL_RE.test(s)).slice(0, 80);
    const results = await Promise.allSettled(symbols.map((s) => snapshot(s)));
    return results.map((r, i) => (r.status === "fulfilled" ? r.value : { symbol: symbols[i], error: true }));
  }
  if (p === "/api/search") {
    const q = (url.searchParams.get("q") || "").slice(0, 60);
    if (!q.trim()) return [];
    const json = await cached(`s:${q}`, 300_000, async () => {
      const res = await fetch(`https://query2.finance.yahoo.com/v1/finance/search?q=${encodeURIComponent(q)}&quotesCount=20&newsCount=0&listsCount=0`, { headers: { "User-Agent": "Mozilla/5.0" } });
      return res.json();
    });
    return (json.quotes || [])
      .filter((x) => x.symbol && ["EQUITY", "ETF", "INDEX", "CRYPTOCURRENCY", "CURRENCY", "FUTURE", "MUTUALFUND"].includes(x.quoteType))
      .map((x) => ({ symbol: x.symbol, name: x.longname || x.shortname || x.symbol, exchange: x.exchDisp, type: x.typeDisp || x.quoteType, market: marketOf(x.symbol) }));
  }
  if (p === "/api/screener/meta") return { markets: Object.fromEntries(Object.entries(SCREENER_MARKETS).map(([k, m]) => [k, { label: m.label, exchanges: m.exchanges, universes: m.universes || null, currency: m.currency, source: m.source || "Yahoo screener" }])), sectors: SECTORS };
  if (p === "/api/screener" && req.method === "POST") return runScreen(await readBody(req));
  if (p === "/api/perf") {
    const symbols = (url.searchParams.get("symbols") || "").split(",").filter((s) => SYMBOL_RE.test(s));
    return performance(symbols);
  }
  if (p === "/api/userdata" && req.method === "GET") return readUserData();
  if (p === "/api/userdata" && req.method === "POST") {
    const body = await readBody(req, 20_000_000);
    if (!body || typeof body.items !== "object" || !Number.isFinite(body.savedAt)) throw new ProviderError("Bad user data", 400);
    const items = Object.fromEntries(Object.entries(body.items).filter(([k, v]) => k.startsWith("bz:") && typeof v === "string"));
    writeUserData({ savedAt: body.savedAt, items });
    return { ok: true, keys: Object.keys(items).length, path: "data/userdata.json" };
  }
  if (p === "/api/providers" && req.method === "GET") return providersView();
  if (p === "/api/routing" && req.method === "POST") {
    const body = await readBody(req);
    for (const [m, id] of Object.entries(body)) {
      if (MARKETS[m] && (id === "auto" || PROVIDERS[id])) config.routing[m] = id;
    }
    saveConfig(config);
    cache.clear();
    return providersView();
  }
  // Broker login (Zerodha): the page opens the broker's login page; the broker sends the browser back here.
  const lm = /^\/api\/providers\/([a-z]+)\/login$/.exec(p);
  if (lm && PROVIDERS[lm[1]]?.login) {
    const prov = PROVIDERS[lm[1]], c = config.providers[prov.id];
    if (!prov.fields.every((f) => f.optional || c?.[f.key])) throw new ProviderError("Save the API key and secret first", 400);
    return { url: prov.login.url(c) };
  }
  const pm = /^\/api\/providers\/([a-z]+)(\/test)?$/.exec(p);
  if (pm && PROVIDERS[pm[1]] && !PROVIDERS[pm[1]].builtIn) {
    const prov = PROVIDERS[pm[1]];
    if (pm[2] && req.method === "POST") {
      if (!isConfigured(prov.id)) throw new ProviderError("Save the key first", 400);
      const started = Date.now();
      const candles = await prov.candles(prov.testSymbol, "1d", config.providers[prov.id]);
      return { ok: true, symbol: prov.testSymbol, candles: candles.length, ms: Date.now() - started };
    }
    if (req.method === "POST") {
      const body = await readBody(req);
      const next = { ...(config.providers[prov.id] || {}) };
      for (const f of prov.fields) {
        const v = typeof body[f.key] === "string" ? body[f.key].trim() : "";
        if (v && !v.startsWith("••••")) next[f.key] = v; // masked value = unchanged
      }
      // New keys mean a new login.
      if (prov.login && (next.apiKey !== config.providers[prov.id]?.apiKey || next.apiSecret !== config.providers[prov.id]?.apiSecret)) {
        delete next.accessToken; delete next.tokenAt; delete next.user;
      }
      config.providers[prov.id] = next;
      saveConfig(config);
      cache.clear();
      return providersView();
    }
    if (req.method === "DELETE") {
      delete config.providers[prov.id];
      for (const [m, id] of Object.entries(config.routing)) if (id === prov.id) config.routing[m] = "auto";
      saveConfig(config);
      cache.clear();
      return providersView();
    }
  }
  throw new ProviderError("Not found", 404);
}

/** Where the broker sends you after logging in: saves today's token and says so in the browser tab. */
async function brokerCallback(prov, url, res) {
  const page = (title, msg) => res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" }).end(`<!doctype html><meta charset="utf-8"><title>LinkCharts</title>
<body style="font:16px system-ui;background:#0f1115;color:#e6e8eb;display:grid;place-items:center;height:90vh;margin:0"><div style="text-align:center">
<h2>${title}</h2><p style="color:#8a919c">${msg}</p></div></body>`);
  const esc = (s) => String(s).replace(/[<>&"]/g, (ch) => `&#${ch.charCodeAt(0)};`);
  const token = url.searchParams.get("request_token");
  if (url.searchParams.get("status") !== "success" || !token) return page("Login cancelled", "Go back to LinkCharts and click Log in again.");
  try {
    const c = config.providers[prov.id] || {};
    config.providers[prov.id] = { ...c, ...(await prov.session(c, token)) };
    saveConfig(config);
    cache.clear();
    page(`✓ Connected to ${esc(prov.name.split(" ")[0])}`, `${config.providers[prov.id].user ? `Logged in as ${esc(config.providers[prov.id].user)}. ` : ""}You can close this tab and go back to LinkCharts.`);
  } catch (e) {
    page("Couldn't log in", `${esc(e.message)}<br>Check the API secret in LinkCharts (⚙), then log in again.`);
  }
}

http.createServer(async (req, res) => {
  if (!authorized(req)) {
    res.writeHead(401, { "WWW-Authenticate": 'Basic realm="LinkCharts", charset="UTF-8"', "Cache-Control": "no-store" });
    res.end("Authentication required");
    return;
  }
  const url = new URL(req.url, "http://localhost");
  const cb = /^\/api\/([a-z]+)\/callback$/.exec(url.pathname);
  if (cb && PROVIDERS[cb[1]]?.login) return brokerCallback(PROVIDERS[cb[1]], url, res);
  if (url.pathname.startsWith("/api/")) {
    try {
      const data = await handleApi(req, url);
      res.writeHead(200, { "Content-Type": "application/json", "Cache-Control": "no-store" }).end(JSON.stringify(data));
    } catch (err) {
      res.writeHead(err.status && err.status >= 400 && err.status < 600 ? err.status : 502, { "Content-Type": "application/json" })
        .end(JSON.stringify({ error: err.message }));
    }
    return;
  }
  if (url.pathname.startsWith("/data/")) { res.writeHead(404).end("not found"); return; } // never serve stored keys
  const file = path.join(root, url.pathname === "/" ? "index.html" : decodeURIComponent(url.pathname));
  if (!file.startsWith(root) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    res.writeHead(404).end("not found");
    return;
  }
  res.writeHead(200, { "Content-Type": types[path.extname(file)] || "application/octet-stream", "Cache-Control": "no-store" });
  fs.createReadStream(file).pipe(res);
}).on("error", (e) => {
  if (e.code !== "EADDRINUSE") throw e;
  // Probably LinkCharts is already running (e.g. started twice): just open it.
  console.log(`Port ${port} is already in use. If LinkCharts is already running, open http://localhost:${port}`);
  if (openBrowser) launchBrowser(`http://localhost:${port}`);
}).listen(port, host, () => {
  console.log(`LinkCharts running on ${host}:${port}`);
  if (process.env.LINKCHARTS_PUBLIC === "1") console.log("Public hosting protection: HTTP Basic Auth enabled.");
  console.log("Keep this window open while you use LinkCharts. Close it (or press Ctrl+C) to stop.");
  if (openBrowser) launchBrowser(`http://localhost:${port}`);
});
